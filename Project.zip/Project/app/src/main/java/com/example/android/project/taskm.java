package com.example.android.project;

public class taskm {

    String Deadline,Description,Employee,Status,Titlet;

    public String getDeadline() {
        return Deadline;
    }

    public void setDeadline(String deadline) {
        Deadline = deadline;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getEmployee() {
        return Employee;
    }

    public void setEmployee(String employee) {
        Employee = employee;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getTitlet() {
        return Titlet;
    }

    public void setTitlet(String titlet) {
        Titlet = titlet;
    }
}
